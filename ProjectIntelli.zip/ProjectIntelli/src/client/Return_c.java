package client;

public class Return_c {

    public String port1;
    public String hostname1;
    public String hostname2;
    public int serversocket1;
    public String port2;
    public int serversocket2;


    public Return_c(String port1, String hostname1, String hostname2, int serversocket1, String port2, int serversocket2){
        this.port1 = port1;
        this.hostname1 = hostname1;
        this.hostname2 = hostname2;
        this.serversocket1 = serversocket1;
        this.port2 = port2;
        this.serversocket2 = serversocket2;
    }
}